﻿namespace Cards
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split(", ", StringSplitOptions.RemoveEmptyEntries);
            
            
            List<Card> cards = new List<Card>();
            
            foreach (string cardInfo in input)
            {
                string[] tokens = cardInfo.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string face = tokens[0];
                string suit = tokens[1];
                
                try
                {
                    
                    Card card = new Card(face, suit);
                    cards.Add(card.CreateCard(face, suit));
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            Console.WriteLine(string.Join(" ", cards));
        }
    }
}